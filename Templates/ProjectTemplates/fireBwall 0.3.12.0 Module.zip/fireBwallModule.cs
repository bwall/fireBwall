﻿using System;
using System.Collections.Generic;
using System.Text;
using fireBwall.Modules;
using fireBwall.Packets;

namespace $safeprojectname$
{
    public class $safeprojectname$Module : NDISModule
    {
        public $safeprojectname$Module() : base()
        {
			ModuleMeta.Meta m = new ModuleMeta.Meta();
			m.Name = "$safeprojectname$";
			m.Version = "0.0.0.1";
			m.Author = "";
			m.Description = "";
			m.Help = "";
			m.Contact = "";
			MetaData = new ModuleMeta(m);
        }

        public override bool ModuleStart()
        {
            throw new NotImplementedException();
        }

        public override bool ModuleStop()
        {
            throw new NotImplementedException();
        }

        public override PacketMainReturnType interiorMain(ref Packet in_packet)
        {
            throw new NotImplementedException();
        }
    }
}
